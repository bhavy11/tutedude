#importkinter

from tkinter import *

#gui interaction
window = Tk()
window.geometry('500x500')

#adding inputs

#Enter Box
c = Entry(window,width=56, borderwidth=5)
c.place(x = 0, y = 0)

#Buttons
def click(num):
    result= c.get()
    c.delete(0, END)
    c.insert(0, str(result + str(num)))
b = Button(window, text = '1', width=12, command = lambda:click(1))
b.place(x = 10, y = 60)

b = Button(window, text = '2', width=12, command = lambda:click(2))
b.place(x = 80, y = 60)

b = Button(window, text = '3', width=12, command = lambda:click(3))
b.place(x = 170, y = 60)

b = Button(window, text = '4', width=12, command = lambda:click(4))
b.place(x = 10, y = 120)

b = Button(window, text = '5', width=12, command = lambda:click(5))
b.place(x = 80, y = 120)

b = Button(window, text = '6', width=12, command = lambda:click(6))
b.place(x = 170, y = 120)

b = Button(window, text = '7', width=12, command = lambda:click(7))
b.place(x = 10, y = 180)

b = Button(window, text = '8', width=12, command = lambda:click(8))
b.place(x = 80, y = 180)

b = Button(window, text = '9', width=12, command = lambda:click(9))
b.place(x = 170, y = 180)

b = Button(window, text = '0', width=12, command = lambda:click(0))
b.place(x = 80, y = 240)

#Operators

def add():
    n1 = c.get()
    global i
    global math
    math = "addition"
    i = int(n1)
    c.delete(0, END)

b = Button(window, text = '+', width=8, command = add)
b.place(x = 280, y = 60)

def sub():
    n1 = c.get()
    global i
    global math
    math = "subtraction"
    i = int(n1)
    c.delete(0, END)

b = Button(window, text = '-', width=8, command = sub)
b.place(x = 280, y = 120)

def mult():
    n1 = c.get()
    global math
    math = "multiplication"
    global i
    i = int(n1)
    c.delete(0, END)

b = Button(window, text = '*', width=8, command = mult)
b.place(x = 280, y = 180)

def div():
    n1 = c.get()
    global i
    global math
    math = "division"
    i = int(n1)
    c.delete(0, END)

b = Button(window, text = '/', width=8, command = div)
b.place(x = 280, y = 240)


def equal():
    n2 = c.get()
    c.delete(0, END)
    if math == "addition":
        c.insert(0,i + int(n2))
    elif math == "subtraction":
        c.insert(0, i - int(n2))
    elif math == "multiplication":
        c.insert(0, i * int(n2))
    elif math == "division":
        c.insert(0, i / int(n2))


b = Button(window, text='=', width=11, command=equal)
b.place(x=180, y=240)

def clear():
    c.delete(0, END)

b = Button(window, text = 'clear', width=9, command = clear)
b.place(x = 10, y = 240)

#mainloop

mainloop()